(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var Helpers;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['handlebar-helpers'] = {
  Helpers: Helpers
};

})();
