/* Imports for global scope */

Async = Package.npm.Async;
Helpers = Package['handlebar-helpers'].Helpers;
HTTP = Package.http.HTTP;
moment = Package.moment.moment;
d3 = Package.d3.d3;
_ = Package.underscore._;
Meteor = Package.meteor.Meteor;
Log = Package.logging.Log;
Deps = Package.deps.Deps;
Session = Package.session.Session;
DDP = Package.livedata.DDP;
Template = Package.templating.Template;
Handlebars = Package.handlebars.Handlebars;
check = Package.check.check;
Match = Package.check.Match;
$ = Package.jquery.$;
jQuery = Package.jquery.jQuery;
Random = Package.random.Random;
EJSON = Package.ejson.EJSON;
Accounts = Package['accounts-base'].Accounts;
Spark = Package.spark.Spark;

