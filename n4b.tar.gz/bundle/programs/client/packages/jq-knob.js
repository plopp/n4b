//////////////////////////////////////////////////////////////////////////
//                                                                      //
// This is a generated file. You can view the original                  //
// source in your browser if your browser supports source maps.         //
//                                                                      //
// If you are using Chrome, open the Developer Tools and click the gear //
// icon in its lower right corner. In the General Settings panel, turn  //
// on 'Enable source maps'.                                             //
//                                                                      //
// If you are using Firefox 23, go to `about:config` and set the        //
// `devtools.debugger.source-maps-enabled` preference to true.          //
// (The preference should be on by default in Firefox 24; versions      //
// older than 23 do not support source maps.)                           //
//                                                                      //
//////////////////////////////////////////////////////////////////////////


(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                     //
// packages/jq-knob/lib/js/jquery.knob.js                                                              //
//                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                       //
/*!jQuery Knob*/                                                                                       // 1
/**                                                                                                    // 2
 * Downward compatible, touchable dial                                                                 // 3
 *                                                                                                     // 4
 * Version: 1.2.0 (15/07/2012)                                                                         // 5
 * Requires: jQuery v1.7+                                                                              // 6
 *                                                                                                     // 7
 * Copyright (c) 2012 Anthony Terrien                                                                  // 8
 * Under MIT and GPL licenses:                                                                         // 9
 *  http://www.opensource.org/licenses/mit-license.php                                                 // 10
 *  http://www.gnu.org/licenses/gpl.html                                                               // 11
 *                                                                                                     // 12
 * Thanks to vor, eskimoblood, spiffistan, FabrizioC                                                   // 13
 */                                                                                                    // 14
(function($) {                                                                                         // 15
                                                                                                       // 16
    /**                                                                                                // 17
     * Kontrol library                                                                                 // 18
     */                                                                                                // 19
    "use strict";                                                                                      // 20
                                                                                                       // 21
    /**                                                                                                // 22
     * Definition of globals and core                                                                  // 23
     */                                                                                                // 24
    var k = {}, // kontrol                                                                             // 25
        max = Math.max,                                                                                // 26
        min = Math.min;                                                                                // 27
                                                                                                       // 28
    k.c = {};                                                                                          // 29
    k.c.d = $(document);                                                                               // 30
    k.c.t = function (e) {                                                                             // 31
        return e.originalEvent.touches.length - 1;                                                     // 32
    };                                                                                                 // 33
                                                                                                       // 34
    /**                                                                                                // 35
     * Kontrol Object                                                                                  // 36
     *                                                                                                 // 37
     * Definition of an abstract UI control                                                            // 38
     *                                                                                                 // 39
     * Each concrete component must call this one.                                                     // 40
     * <code>                                                                                          // 41
     * k.o.call(this);                                                                                 // 42
     * </code>                                                                                         // 43
     */                                                                                                // 44
    k.o = function () {                                                                                // 45
        var s = this;                                                                                  // 46
                                                                                                       // 47
        this.o = null; // array of options                                                             // 48
        this.$ = null; // jQuery wrapped element                                                       // 49
        this.i = null; // mixed HTMLInputElement or array of HTMLInputElement                          // 50
        this.g = null; // deprecated 2D graphics context for 'pre-rendering'                           // 51
        this.v = null; // value ; mixed array or integer                                               // 52
        this.cv = null; // change value ; not commited value                                           // 53
        this.x = 0; // canvas x position                                                               // 54
        this.y = 0; // canvas y position                                                               // 55
        this.w = 0; // canvas width                                                                    // 56
        this.h = 0; // canvas height                                                                   // 57
        this.$c = null; // jQuery canvas element                                                       // 58
        this.c = null; // rendered canvas context                                                      // 59
        this.t = 0; // touches index                                                                   // 60
        this.isInit = false;                                                                           // 61
        this.fgColor = null; // main color                                                             // 62
        this.pColor = null; // previous color                                                          // 63
        this.dH = null; // draw hook                                                                   // 64
        this.cH = null; // change hook                                                                 // 65
        this.eH = null; // cancel hook                                                                 // 66
        this.rH = null; // release hook                                                                // 67
        this.scale = 1; // scale factor                                                                // 68
        this.relative = false;                                                                         // 69
        this.relativeWidth = false;                                                                    // 70
        this.relativeHeight = false;                                                                   // 71
        this.$div = null; // component div                                                             // 72
                                                                                                       // 73
        this.run = function () {                                                                       // 74
            var cf = function (e, conf) {                                                              // 75
                var k;                                                                                 // 76
                for (k in conf) {                                                                      // 77
                    s.o[k] = conf[k];                                                                  // 78
                }                                                                                      // 79
                s.init();                                                                              // 80
                s._configure()                                                                         // 81
                 ._draw();                                                                             // 82
            };                                                                                         // 83
                                                                                                       // 84
            if(this.$.data('kontroled')) return;                                                       // 85
            this.$.data('kontroled', true);                                                            // 86
                                                                                                       // 87
            this.extend();                                                                             // 88
            this.o = $.extend(                                                                         // 89
                {                                                                                      // 90
                    // Config                                                                          // 91
                    min : this.$.data('min') || 0,                                                     // 92
                    max : this.$.data('max') || 100,                                                   // 93
                    stopper : true,                                                                    // 94
                    readOnly : this.$.data('readonly') || (this.$.attr('readonly') == 'readonly'),     // 95
                                                                                                       // 96
                    // UI                                                                              // 97
                    cursor : (this.$.data('cursor') === true && 30)                                    // 98
                                || this.$.data('cursor')                                               // 99
                                || 0,                                                                  // 100
                    thickness : (                                                                      // 101
                                this.$.data('thickness')                                               // 102
                                && Math.max(Math.min(this.$.data('thickness'), 1), 0.01)               // 103
                                )                                                                      // 104
                                || 0.35,                                                               // 105
                    lineCap : this.$.data('linecap') || 'butt',                                        // 106
                    width : this.$.data('width') || 200,                                               // 107
                    height : this.$.data('height') || 200,                                             // 108
                    displayInput : this.$.data('displayinput') == null || this.$.data('displayinput'), // 109
                    displayPrevious : this.$.data('displayprevious'),                                  // 110
                    fgColor : this.$.data('fgcolor') || '#87CEEB',                                     // 111
                    inputColor: this.$.data('inputcolor'),                                             // 112
                    font: this.$.data('font') || 'Arial',                                              // 113
                    fontWeight: this.$.data('font-weight') || 'bold',                                  // 114
                    inline : false,                                                                    // 115
                    step : this.$.data('step') || 1,                                                   // 116
                                                                                                       // 117
                    // Hooks                                                                           // 118
                    draw : null, // function () {}                                                     // 119
                    change : null, // function (value) {}                                              // 120
                    cancel : null, // function () {}                                                   // 121
                    release : null, // function (value) {}                                             // 122
                    error : null // function () {}                                                     // 123
                }, this.o                                                                              // 124
            );                                                                                         // 125
                                                                                                       // 126
            // finalize options                                                                        // 127
            if(!this.o.inputColor) {                                                                   // 128
                this.o.inputColor = this.o.fgColor;                                                    // 129
            }                                                                                          // 130
                                                                                                       // 131
            // routing value                                                                           // 132
            if(this.$.is('fieldset')) {                                                                // 133
                                                                                                       // 134
                // fieldset = array of integer                                                         // 135
                this.v = {};                                                                           // 136
                this.i = this.$.find('input')                                                          // 137
                this.i.each(function(k) {                                                              // 138
                    var $this = $(this);                                                               // 139
                    s.i[k] = $this;                                                                    // 140
                    s.v[k] = $this.val();                                                              // 141
                                                                                                       // 142
                    $this.bind(                                                                        // 143
                        'change'                                                                       // 144
                        , function () {                                                                // 145
                            var val = {};                                                              // 146
                            val[k] = $this.val();                                                      // 147
                            s.val(val);                                                                // 148
                        }                                                                              // 149
                    );                                                                                 // 150
                });                                                                                    // 151
                this.$.find('legend').remove();                                                        // 152
                                                                                                       // 153
            } else {                                                                                   // 154
                                                                                                       // 155
                // input = integer                                                                     // 156
                this.i = this.$;                                                                       // 157
                this.v = this.$.val();                                                                 // 158
                (this.v == '') && (this.v = this.o.min);                                               // 159
                                                                                                       // 160
                this.$.bind(                                                                           // 161
                    'change'                                                                           // 162
                    , function () {                                                                    // 163
                        s.val(s._validate(s.$.val()));                                                 // 164
                    }                                                                                  // 165
                );                                                                                     // 166
                                                                                                       // 167
            }                                                                                          // 168
                                                                                                       // 169
            (!this.o.displayInput) && this.$.hide();                                                   // 170
                                                                                                       // 171
            // adds needed DOM elements (canvas, div)                                                  // 172
            this.$c = $(document.createElement('canvas'));                                             // 173
            if (typeof G_vmlCanvasManager !== 'undefined') {                                           // 174
              G_vmlCanvasManager.initElement(this.$c[0]);                                              // 175
            }                                                                                          // 176
            this.c = this.$c[0].getContext ? this.$c[0].getContext('2d') : null;                       // 177
            if (!this.c) {                                                                             // 178
                this.o.error && this.o.error();                                                        // 179
                return;                                                                                // 180
            }                                                                                          // 181
                                                                                                       // 182
            // hdpi support                                                                            // 183
            this.scale = (window.devicePixelRatio || 1) /                                              // 184
                        (                                                                              // 185
                            this.c.webkitBackingStorePixelRatio ||                                     // 186
                            this.c.mozBackingStorePixelRatio ||                                        // 187
                            this.c.msBackingStorePixelRatio ||                                         // 188
                            this.c.oBackingStorePixelRatio ||                                          // 189
                            this.c.backingStorePixelRatio || 1                                         // 190
                        );                                                                             // 191
                                                                                                       // 192
            // detects relative width / height                                                         // 193
            this.relativeWidth = ((this.o.width % 1 !== 0)                                             // 194
                                    && this.o.width.indexOf('%'));                                     // 195
            this.relativeHeight = ((this.o.height % 1 !== 0)                                           // 196
                                    && this.o.height.indexOf('%'));                                    // 197
                                                                                                       // 198
            this.relative = (this.relativeWidth || this.relativeHeight);                               // 199
                                                                                                       // 200
            // wraps all elements in a div                                                             // 201
            this.$div = $('<div style="'                                                               // 202
                        + (this.o.inline ? 'display:inline;' : '')                                     // 203
                        + '"></div>');                                                                 // 204
                                                                                                       // 205
            this.$.wrap(this.$div).before(this.$c);                                                    // 206
            this.$div = this.$.parent();                                                               // 207
                                                                                                       // 208
            // computes size and carves the component                                                  // 209
            this._carve();                                                                             // 210
                                                                                                       // 211
            // prepares props for transaction                                                          // 212
            if (this.v instanceof Object) {                                                            // 213
                this.cv = {};                                                                          // 214
                this.copy(this.v, this.cv);                                                            // 215
            } else {                                                                                   // 216
                this.cv = this.v;                                                                      // 217
            }                                                                                          // 218
                                                                                                       // 219
            // binds configure event                                                                   // 220
            this.$                                                                                     // 221
                .bind("configure", cf)                                                                 // 222
                .parent()                                                                              // 223
                .bind("configure", cf);                                                                // 224
                                                                                                       // 225
            // finalize init                                                                           // 226
            this._listen()                                                                             // 227
                ._configure()                                                                          // 228
                ._xy()                                                                                 // 229
                .init();                                                                               // 230
                                                                                                       // 231
            this.isInit = true;                                                                        // 232
                                                                                                       // 233
            // the most important !                                                                    // 234
            this._draw();                                                                              // 235
                                                                                                       // 236
            return this;                                                                               // 237
        };                                                                                             // 238
                                                                                                       // 239
        this._carve = function() {                                                                     // 240
            if(this.relative) {                                                                        // 241
                var w = this.relativeWidth                                                             // 242
                            ? this.$div.parent().width()                                               // 243
                                * parseInt(this.o.width) / 100                                         // 244
                            : this.$div.parent().width(),                                              // 245
                    h = this.relativeHeight                                                            // 246
                            ? this.$div.parent().height()                                              // 247
                                * parseInt(this.o.height) / 100                                        // 248
                            : this.$div.parent().height();                                             // 249
                                                                                                       // 250
                // apply relative                                                                      // 251
                this.w = this.h = Math.min(w, h);                                                      // 252
            } else {                                                                                   // 253
                this.w = this.o.width;                                                                 // 254
                this.h = this.o.height;                                                                // 255
            }                                                                                          // 256
                                                                                                       // 257
            // finalize div                                                                            // 258
            this.$div.css({                                                                            // 259
                'width': this.w + 'px',                                                                // 260
                'height': this.h + 'px'                                                                // 261
            });                                                                                        // 262
                                                                                                       // 263
            // finalize canvas with computed width                                                     // 264
            this.$c.attr({                                                                             // 265
                width: this.w,                                                                         // 266
                height: this.h                                                                         // 267
            });                                                                                        // 268
                                                                                                       // 269
            // scaling                                                                                 // 270
            if (this.scale !== 1) {                                                                    // 271
                this.$c[0].width = this.$c[0].width * this.scale;                                      // 272
                this.$c[0].height = this.$c[0].height * this.scale;                                    // 273
                this.$c.width(this.w);                                                                 // 274
                this.$c.height(this.h);                                                                // 275
            }                                                                                          // 276
                                                                                                       // 277
            return this;                                                                               // 278
        }                                                                                              // 279
                                                                                                       // 280
        this._draw = function () {                                                                     // 281
                                                                                                       // 282
            // canvas pre-rendering                                                                    // 283
            var d = true;                                                                              // 284
                                                                                                       // 285
            s.g = s.c;                                                                                 // 286
                                                                                                       // 287
            s.clear();                                                                                 // 288
                                                                                                       // 289
            s.dH                                                                                       // 290
            && (d = s.dH());                                                                           // 291
                                                                                                       // 292
            (d !== false) && s.draw();                                                                 // 293
                                                                                                       // 294
        };                                                                                             // 295
                                                                                                       // 296
        this._touch = function (e) {                                                                   // 297
                                                                                                       // 298
            var touchMove = function (e) {                                                             // 299
                                                                                                       // 300
                var v = s.xy2val(                                                                      // 301
                            e.originalEvent.touches[s.t].pageX,                                        // 302
                            e.originalEvent.touches[s.t].pageY                                         // 303
                            );                                                                         // 304
                                                                                                       // 305
                if (v == s.cv) return;                                                                 // 306
                                                                                                       // 307
                if (                                                                                   // 308
                    s.cH                                                                               // 309
                    && (s.cH(v) === false)                                                             // 310
                ) return;                                                                              // 311
                                                                                                       // 312
                                                                                                       // 313
                s.change(s._validate(v));                                                              // 314
                s._draw();                                                                             // 315
            };                                                                                         // 316
                                                                                                       // 317
            // get touches index                                                                       // 318
            this.t = k.c.t(e);                                                                         // 319
                                                                                                       // 320
            // First touch                                                                             // 321
            touchMove(e);                                                                              // 322
                                                                                                       // 323
            // Touch events listeners                                                                  // 324
            k.c.d                                                                                      // 325
                .bind("touchmove.k", touchMove)                                                        // 326
                .bind(                                                                                 // 327
                    "touchend.k"                                                                       // 328
                    , function () {                                                                    // 329
                        k.c.d.unbind('touchmove.k touchend.k');                                        // 330
                                                                                                       // 331
                        if (                                                                           // 332
                            s.rH                                                                       // 333
                            && (s.rH(s.cv) === false)                                                  // 334
                        ) return;                                                                      // 335
                                                                                                       // 336
                        s.val(s.cv);                                                                   // 337
                    }                                                                                  // 338
                );                                                                                     // 339
                                                                                                       // 340
            return this;                                                                               // 341
        };                                                                                             // 342
                                                                                                       // 343
        this._mouse = function (e) {                                                                   // 344
                                                                                                       // 345
            var mouseMove = function (e) {                                                             // 346
                var v = s.xy2val(e.pageX, e.pageY);                                                    // 347
                if (v == s.cv) return;                                                                 // 348
                                                                                                       // 349
                if (                                                                                   // 350
                    s.cH                                                                               // 351
                    && (s.cH(v) === false)                                                             // 352
                ) return;                                                                              // 353
                                                                                                       // 354
                s.change(s._validate(v));                                                              // 355
                s._draw();                                                                             // 356
            };                                                                                         // 357
                                                                                                       // 358
            // First click                                                                             // 359
            mouseMove(e);                                                                              // 360
                                                                                                       // 361
            // Mouse events listeners                                                                  // 362
            k.c.d                                                                                      // 363
                .bind("mousemove.k", mouseMove)                                                        // 364
                .bind(                                                                                 // 365
                    // Escape key cancel current change                                                // 366
                    "keyup.k"                                                                          // 367
                    , function (e) {                                                                   // 368
                        if (e.keyCode === 27) {                                                        // 369
                            k.c.d.unbind("mouseup.k mousemove.k keyup.k");                             // 370
                                                                                                       // 371
                            if (                                                                       // 372
                                s.eH                                                                   // 373
                                && (s.eH() === false)                                                  // 374
                            ) return;                                                                  // 375
                                                                                                       // 376
                            s.cancel();                                                                // 377
                        }                                                                              // 378
                    }                                                                                  // 379
                )                                                                                      // 380
                .bind(                                                                                 // 381
                    "mouseup.k"                                                                        // 382
                    , function (e) {                                                                   // 383
                        k.c.d.unbind('mousemove.k mouseup.k keyup.k');                                 // 384
                                                                                                       // 385
                        if (                                                                           // 386
                            s.rH                                                                       // 387
                            && (s.rH(s.cv) === false)                                                  // 388
                        ) return;                                                                      // 389
                                                                                                       // 390
                        s.val(s.cv);                                                                   // 391
                    }                                                                                  // 392
                );                                                                                     // 393
                                                                                                       // 394
            return this;                                                                               // 395
        };                                                                                             // 396
                                                                                                       // 397
        this._xy = function () {                                                                       // 398
            var o = this.$c.offset();                                                                  // 399
            this.x = o.left;                                                                           // 400
            this.y = o.top;                                                                            // 401
            return this;                                                                               // 402
        };                                                                                             // 403
                                                                                                       // 404
        this._listen = function () {                                                                   // 405
                                                                                                       // 406
            if (!this.o.readOnly) {                                                                    // 407
                this.$c                                                                                // 408
                    .bind(                                                                             // 409
                        "mousedown"                                                                    // 410
                        , function (e) {                                                               // 411
                            e.preventDefault();                                                        // 412
                            s._xy()._mouse(e);                                                         // 413
                         }                                                                             // 414
                    )                                                                                  // 415
                    .bind(                                                                             // 416
                        "touchstart"                                                                   // 417
                        , function (e) {                                                               // 418
                            e.preventDefault();                                                        // 419
                            s._xy()._touch(e);                                                         // 420
                         }                                                                             // 421
                    );                                                                                 // 422
                                                                                                       // 423
                this.listen();                                                                         // 424
            } else {                                                                                   // 425
                this.$.attr('readonly', 'readonly');                                                   // 426
            }                                                                                          // 427
                                                                                                       // 428
            if(this.relative) {                                                                        // 429
                $(window).resize(function() {                                                          // 430
                    s._carve()                                                                         // 431
                     .init();                                                                          // 432
                    s._draw();                                                                         // 433
                });                                                                                    // 434
            }                                                                                          // 435
                                                                                                       // 436
            return this;                                                                               // 437
        };                                                                                             // 438
                                                                                                       // 439
        this._configure = function () {                                                                // 440
                                                                                                       // 441
            // Hooks                                                                                   // 442
            if (this.o.draw) this.dH = this.o.draw;                                                    // 443
            if (this.o.change) this.cH = this.o.change;                                                // 444
            if (this.o.cancel) this.eH = this.o.cancel;                                                // 445
            if (this.o.release) this.rH = this.o.release;                                              // 446
                                                                                                       // 447
            if (this.o.displayPrevious) {                                                              // 448
                this.pColor = this.h2rgba(this.o.fgColor, "0.4");                                      // 449
                this.fgColor = this.h2rgba(this.o.fgColor, "0.6");                                     // 450
            } else {                                                                                   // 451
                this.fgColor = this.o.fgColor;                                                         // 452
            }                                                                                          // 453
                                                                                                       // 454
            return this;                                                                               // 455
        };                                                                                             // 456
                                                                                                       // 457
        this._clear = function () {                                                                    // 458
            this.$c[0].width = this.$c[0].width;                                                       // 459
        };                                                                                             // 460
                                                                                                       // 461
        this._validate = function(v) {                                                                 // 462
            return (~~ (((v < 0) ? -0.5 : 0.5) + (v/this.o.step))) * this.o.step;                      // 463
        };                                                                                             // 464
                                                                                                       // 465
        // Abstract methods                                                                            // 466
        this.listen = function () {}; // on start, one time                                            // 467
        this.extend = function () {}; // each time configure triggered                                 // 468
        this.init = function () {}; // each time configure triggered                                   // 469
        this.change = function (v) {}; // on change                                                    // 470
        this.val = function (v) {}; // on release                                                      // 471
        this.xy2val = function (x, y) {}; //                                                           // 472
        this.draw = function () {}; // on change / on release                                          // 473
        this.clear = function () { this._clear(); };                                                   // 474
                                                                                                       // 475
        // Utils                                                                                       // 476
        this.h2rgba = function (h, a) {                                                                // 477
            var rgb;                                                                                   // 478
            h = h.substring(1,7)                                                                       // 479
            rgb = [parseInt(h.substring(0,2),16)                                                       // 480
                   ,parseInt(h.substring(2,4),16)                                                      // 481
                   ,parseInt(h.substring(4,6),16)];                                                    // 482
            return "rgba(" + rgb[0] + "," + rgb[1] + "," + rgb[2] + "," + a + ")";                     // 483
        };                                                                                             // 484
                                                                                                       // 485
        this.copy = function (f, t) {                                                                  // 486
            for (var i in f) { t[i] = f[i]; }                                                          // 487
        };                                                                                             // 488
    };                                                                                                 // 489
                                                                                                       // 490
                                                                                                       // 491
    /**                                                                                                // 492
     * k.Dial                                                                                          // 493
     */                                                                                                // 494
    k.Dial = function () {                                                                             // 495
        k.o.call(this);                                                                                // 496
                                                                                                       // 497
        this.startAngle = null;                                                                        // 498
        this.xy = null;                                                                                // 499
        this.radius = null;                                                                            // 500
        this.lineWidth = null;                                                                         // 501
        this.cursorExt = null;                                                                         // 502
        this.w2 = null;                                                                                // 503
        this.PI2 = 2*Math.PI;                                                                          // 504
                                                                                                       // 505
        this.extend = function () {                                                                    // 506
            this.o = $.extend(                                                                         // 507
                {                                                                                      // 508
                    bgColor : this.$.data('bgcolor') || '#EEEEEE',                                     // 509
                    angleOffset : this.$.data('angleoffset') || 0,                                     // 510
                    angleArc : this.$.data('anglearc') || 360,                                         // 511
                    inline : true                                                                      // 512
                }, this.o                                                                              // 513
            );                                                                                         // 514
        };                                                                                             // 515
                                                                                                       // 516
        this.val = function (v) {                                                                      // 517
            if (null != v) {                                                                           // 518
                this.cv = this.o.stopper ? max(min(v, this.o.max), this.o.min) : v;                    // 519
                this.v = this.cv;                                                                      // 520
                this.$.val(this.v);                                                                    // 521
                this._draw();                                                                          // 522
            } else {                                                                                   // 523
                return this.v;                                                                         // 524
            }                                                                                          // 525
        };                                                                                             // 526
                                                                                                       // 527
        this.xy2val = function (x, y) {                                                                // 528
            var a, ret;                                                                                // 529
                                                                                                       // 530
            a = Math.atan2(                                                                            // 531
                        x - (this.x + this.w2)                                                         // 532
                        , - (y - this.y - this.w2)                                                     // 533
                    ) - this.angleOffset;                                                              // 534
                                                                                                       // 535
            if(this.angleArc != this.PI2 && (a < 0) && (a > -0.5)) {                                   // 536
                // if isset angleArc option, set to min if .5 under min                                // 537
                a = 0;                                                                                 // 538
            } else if (a < 0) {                                                                        // 539
                a += this.PI2;                                                                         // 540
            }                                                                                          // 541
                                                                                                       // 542
            ret = ~~ (0.5 + (a * (this.o.max - this.o.min) / this.angleArc))                           // 543
                    + this.o.min;                                                                      // 544
                                                                                                       // 545
            this.o.stopper                                                                             // 546
            && (ret = max(min(ret, this.o.max), this.o.min));                                          // 547
                                                                                                       // 548
            return ret;                                                                                // 549
        };                                                                                             // 550
                                                                                                       // 551
        this.listen = function () {                                                                    // 552
            // bind MouseWheel                                                                         // 553
            var s = this,                                                                              // 554
                mw = function (e) {                                                                    // 555
                            e.preventDefault();                                                        // 556
                            var ori = e.originalEvent                                                  // 557
                                ,deltaX = ori.detail || ori.wheelDeltaX                                // 558
                                ,deltaY = ori.detail || ori.wheelDeltaY                                // 559
                                ,v = parseInt(s.$.val()) + (deltaX>0 || deltaY>0 ? s.o.step : deltaX<0 || deltaY<0 ? -s.o.step : 0);
                                                                                                       // 561
                            if (                                                                       // 562
                                s.cH                                                                   // 563
                                && (s.cH(v) === false)                                                 // 564
                            ) return;                                                                  // 565
                                                                                                       // 566
                            s.val(v);                                                                  // 567
                        }                                                                              // 568
                , kval, to, m = 1, kv = {37:-s.o.step, 38:s.o.step, 39:s.o.step, 40:-s.o.step};        // 569
                                                                                                       // 570
            this.$                                                                                     // 571
                .bind(                                                                                 // 572
                    "keydown"                                                                          // 573
                    ,function (e) {                                                                    // 574
                        var kc = e.keyCode;                                                            // 575
                                                                                                       // 576
                        // numpad support                                                              // 577
                        if(kc >= 96 && kc <= 105) {                                                    // 578
                            kc = e.keyCode = kc - 48;                                                  // 579
                        }                                                                              // 580
                                                                                                       // 581
                        kval = parseInt(String.fromCharCode(kc));                                      // 582
                                                                                                       // 583
                        if (isNaN(kval)) {                                                             // 584
                                                                                                       // 585
                            (kc !== 13)         // enter                                               // 586
                            && (kc !== 8)       // bs                                                  // 587
                            && (kc !== 9)       // tab                                                 // 588
                            && (kc !== 189)     // -                                                   // 589
                            && e.preventDefault();                                                     // 590
                                                                                                       // 591
                            // arrows                                                                  // 592
                            if ($.inArray(kc,[37,38,39,40]) > -1) {                                    // 593
                                e.preventDefault();                                                    // 594
                                                                                                       // 595
                                var v = parseInt(s.$.val()) + kv[kc] * m;                              // 596
                                                                                                       // 597
                                s.o.stopper                                                            // 598
                                && (v = max(min(v, s.o.max), s.o.min));                                // 599
                                                                                                       // 600
                                s.change(v);                                                           // 601
                                s._draw();                                                             // 602
                                                                                                       // 603
                                // long time keydown speed-up                                          // 604
                                to = window.setTimeout(                                                // 605
                                    function () { m*=2; }                                              // 606
                                    ,30                                                                // 607
                                );                                                                     // 608
                            }                                                                          // 609
                        }                                                                              // 610
                    }                                                                                  // 611
                )                                                                                      // 612
                .bind(                                                                                 // 613
                    "keyup"                                                                            // 614
                    ,function (e) {                                                                    // 615
                        if (isNaN(kval)) {                                                             // 616
                            if (to) {                                                                  // 617
                                window.clearTimeout(to);                                               // 618
                                to = null;                                                             // 619
                                m = 1;                                                                 // 620
                                s.val(s.$.val());                                                      // 621
                            }                                                                          // 622
                        } else {                                                                       // 623
                            // kval postcond                                                           // 624
                            (s.$.val() > s.o.max && s.$.val(s.o.max))                                  // 625
                            || (s.$.val() < s.o.min && s.$.val(s.o.min));                              // 626
                        }                                                                              // 627
                                                                                                       // 628
                    }                                                                                  // 629
                );                                                                                     // 630
                                                                                                       // 631
            this.$c.bind("mousewheel DOMMouseScroll", mw);                                             // 632
            this.$.bind("mousewheel DOMMouseScroll", mw)                                               // 633
        };                                                                                             // 634
                                                                                                       // 635
        this.init = function () {                                                                      // 636
                                                                                                       // 637
            if (                                                                                       // 638
                this.v < this.o.min                                                                    // 639
                || this.v > this.o.max                                                                 // 640
            ) this.v = this.o.min;                                                                     // 641
                                                                                                       // 642
            this.$.val(this.v);                                                                        // 643
            this.w2 = this.w / 2;                                                                      // 644
            this.cursorExt = this.o.cursor / 100;                                                      // 645
            this.xy = this.w2 * this.scale;                                                            // 646
            this.lineWidth = this.xy * this.o.thickness;                                               // 647
            this.lineCap = this.o.lineCap;                                                             // 648
            this.radius = this.xy - this.lineWidth / 2;                                                // 649
                                                                                                       // 650
            this.o.angleOffset                                                                         // 651
            && (this.o.angleOffset = isNaN(this.o.angleOffset) ? 0 : this.o.angleOffset);              // 652
                                                                                                       // 653
            this.o.angleArc                                                                            // 654
            && (this.o.angleArc = isNaN(this.o.angleArc) ? this.PI2 : this.o.angleArc);                // 655
                                                                                                       // 656
            // deg to rad                                                                              // 657
            this.angleOffset = this.o.angleOffset * Math.PI / 180;                                     // 658
            this.angleArc = this.o.angleArc * Math.PI / 180;                                           // 659
                                                                                                       // 660
            // compute start and end angles                                                            // 661
            this.startAngle = 1.5 * Math.PI + this.angleOffset;                                        // 662
            this.endAngle = 1.5 * Math.PI + this.angleOffset + this.angleArc;                          // 663
                                                                                                       // 664
            var s = max(                                                                               // 665
                            String(Math.abs(this.o.max)).length                                        // 666
                            , String(Math.abs(this.o.min)).length                                      // 667
                            , 2                                                                        // 668
                            ) + 2;                                                                     // 669
                                                                                                       // 670
            this.o.displayInput                                                                        // 671
                && this.i.css({                                                                        // 672
                        'width' : ((this.w / 2 + 4) >> 0) + 'px'                                       // 673
                        ,'height' : ((this.w / 3) >> 0) + 'px'                                         // 674
                        ,'position' : 'absolute'                                                       // 675
                        ,'vertical-align' : 'middle'                                                   // 676
                        ,'margin-top' : ((this.w / 3) >> 0) + 'px'                                     // 677
                        ,'margin-left' : '-' + ((this.w * 3 / 4 + 2) >> 0) + 'px'                      // 678
                        ,'border' : 0                                                                  // 679
                        ,'background' : 'none'                                                         // 680
                        ,'font' : this.o.fontWeight + ' ' + ((this.w / s) >> 0) + 'px ' + this.o.font  // 681
                        ,'text-align' : 'center'                                                       // 682
                        ,'color' : this.o.inputColor || this.o.fgColor                                 // 683
                        ,'padding' : '0px'                                                             // 684
                        ,'-webkit-appearance': 'none'                                                  // 685
                        })                                                                             // 686
                || this.i.css({                                                                        // 687
                        'width' : '0px'                                                                // 688
                        ,'visibility' : 'hidden'                                                       // 689
                        });                                                                            // 690
        };                                                                                             // 691
                                                                                                       // 692
        this.change = function (v) {                                                                   // 693
            this.cv = v;                                                                               // 694
            this.$.val(v);                                                                             // 695
        };                                                                                             // 696
                                                                                                       // 697
        this.angle = function (v) {                                                                    // 698
            return (v - this.o.min) * this.angleArc / (this.o.max - this.o.min);                       // 699
        };                                                                                             // 700
                                                                                                       // 701
        this.draw = function () {                                                                      // 702
                                                                                                       // 703
            var c = this.g,                 // context                                                 // 704
                a = this.angle(this.cv)    // Angle                                                    // 705
                , sat = this.startAngle     // Start angle                                             // 706
                , eat = sat + a             // End angle                                               // 707
                , sa, ea                    // Previous angles                                         // 708
                , r = 1;                                                                               // 709
                                                                                                       // 710
            c.lineWidth = this.lineWidth;                                                              // 711
                                                                                                       // 712
            c.lineCap = this.lineCap;                                                                  // 713
                                                                                                       // 714
            this.o.cursor                                                                              // 715
                && (sat = eat - this.cursorExt)                                                        // 716
                && (eat = eat + this.cursorExt);                                                       // 717
                                                                                                       // 718
            c.beginPath();                                                                             // 719
                c.strokeStyle = this.o.bgColor;                                                        // 720
                c.arc(this.xy, this.xy, this.radius, this.endAngle, this.startAngle, true);            // 721
            c.stroke();                                                                                // 722
                                                                                                       // 723
            if (this.o.displayPrevious) {                                                              // 724
                ea = this.startAngle + this.angle(this.v);                                             // 725
                sa = this.startAngle;                                                                  // 726
                this.o.cursor                                                                          // 727
                    && (sa = ea - this.cursorExt)                                                      // 728
                    && (ea = ea + this.cursorExt);                                                     // 729
                                                                                                       // 730
                c.beginPath();                                                                         // 731
                    c.strokeStyle = this.pColor;                                                       // 732
                    c.arc(this.xy, this.xy, this.radius, sa, ea, false);                               // 733
                c.stroke();                                                                            // 734
                r = (this.cv == this.v);                                                               // 735
            }                                                                                          // 736
                                                                                                       // 737
            c.beginPath();                                                                             // 738
                c.strokeStyle = r ? this.o.fgColor : this.fgColor ;                                    // 739
                c.arc(this.xy, this.xy, this.radius, sat, eat, false);                                 // 740
            c.stroke();                                                                                // 741
        };                                                                                             // 742
                                                                                                       // 743
        this.cancel = function () {                                                                    // 744
            this.val(this.v);                                                                          // 745
        };                                                                                             // 746
    };                                                                                                 // 747
                                                                                                       // 748
    $.fn.dial = $.fn.knob = function (o) {                                                             // 749
        return this.each(                                                                              // 750
            function () {                                                                              // 751
                var d = new k.Dial();                                                                  // 752
                d.o = o;                                                                               // 753
                d.$ = $(this);                                                                         // 754
                d.run();                                                                               // 755
            }                                                                                          // 756
        ).parent();                                                                                    // 757
    };                                                                                                 // 758
                                                                                                       // 759
})(jQuery);                                                                                            // 760
                                                                                                       // 761
/////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['jq-knob'] = {};

})();

//# sourceMappingURL=720adeb1d9dc281a2b0d0292974f9df27f310493.map
