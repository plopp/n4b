//////////////////////////////////////////////////////////////////////////
//                                                                      //
// This is a generated file. You can view the original                  //
// source in your browser if your browser supports source maps.         //
//                                                                      //
// If you are using Chrome, open the Developer Tools and click the gear //
// icon in its lower right corner. In the General Settings panel, turn  //
// on 'Enable source maps'.                                             //
//                                                                      //
// If you are using Firefox 23, go to `about:config` and set the        //
// `devtools.debugger.source-maps-enabled` preference to true.          //
// (The preference should be on by default in Firefox 24; versions      //
// older than 23 do not support source maps.)                           //
//                                                                      //
//////////////////////////////////////////////////////////////////////////


(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var $ = Package.jquery.$;
var jQuery = Package.jquery.jQuery;

(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/jqbootstrapvalidation/lib/jqBootstrapValidation/dist/jqBootstrapValidation-1.3.6.js                      //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
/*! jqBootstrapValidation - v1.3.6 - 2013-01-23                                                                      // 1
* http://reactiveraven.github.com/jqBootstrapValidation                                                              // 2
* Copyright (c) 2013 David Godfrey; Licensed MIT */                                                                  // 3
                                                                                                                     // 4
(function( $ ){                                                                                                      // 5
                                                                                                                     // 6
	var createdElements = [];                                                                                           // 7
                                                                                                                     // 8
	var defaults = {                                                                                                    // 9
		options: {                                                                                                         // 10
			prependExistingHelpBlock: false,                                                                                  // 11
			sniffHtml: true, // sniff for 'required', 'maxlength', etc                                                        // 12
			preventSubmit: true, // stop the form submit event from firing if validation fails                                // 13
			submitError: false, // function called if there is an error when trying to submit                                 // 14
			submitSuccess: false, // function called just before a successful submit event is sent to the server              // 15
            semanticallyStrict: false, // set to true to tidy up generated HTML output                               // 16
            bindEvents: [],                                                                                          // 17
			autoAdd: {                                                                                                        // 18
				helpBlocks: true                                                                                                 // 19
			},                                                                                                                // 20
      filter: function () {                                                                                          // 21
        // return $(this).is(":visible"); // only validate elements you can see                                      // 22
        return true; // validate everything                                                                          // 23
      }                                                                                                              // 24
		},                                                                                                                 // 25
    methods: {                                                                                                       // 26
      init : function( options ) {                                                                                   // 27
                                                                                                                     // 28
        var settings = $.extend(true, {}, defaults);                                                                 // 29
                                                                                                                     // 30
        settings.options = $.extend(true, settings.options, options);                                                // 31
                                                                                                                     // 32
        var $siblingElements = this;                                                                                 // 33
                                                                                                                     // 34
        var uniqueForms = $.unique(                                                                                  // 35
          $siblingElements.map( function () {                                                                        // 36
            return $(this).parents("form")[0];                                                                       // 37
          }).toArray()                                                                                               // 38
        );                                                                                                           // 39
                                                                                                                     // 40
        $(uniqueForms).bind("submit", function (e) {                                                                 // 41
          var $form = $(this);                                                                                       // 42
          var warningsFound = 0;                                                                                     // 43
          var $inputs = $form.find("input,textarea,select").not("[type=submit],[type=image]").filter(settings.options.filter);
          $inputs.trigger("submit.validation").trigger("validationLostFocus.validation");                            // 45
                                                                                                                     // 46
          $inputs.each(function (i, el) {                                                                            // 47
            var $this = $(el),                                                                                       // 48
              $controlGroup = $this.parents(".control-group").first();                                               // 49
            if (                                                                                                     // 50
              $controlGroup.hasClass("warning")                                                                      // 51
            ) {                                                                                                      // 52
              $controlGroup.removeClass("warning").addClass("error");                                                // 53
              warningsFound++;                                                                                       // 54
            }                                                                                                        // 55
          });                                                                                                        // 56
                                                                                                                     // 57
          if (warningsFound) {                                                                                       // 58
            if (settings.options.preventSubmit) {                                                                    // 59
              e.preventDefault();                                                                                    // 60
            }                                                                                                        // 61
            $form.addClass("error");                                                                                 // 62
            if ($.isFunction(settings.options.submitError)) {                                                        // 63
              settings.options.submitError($form, e, $inputs.jqBootstrapValidation("collectErrors", true));          // 64
            }                                                                                                        // 65
          } else {                                                                                                   // 66
            $form.removeClass("error");                                                                              // 67
            if ($.isFunction(settings.options.submitSuccess)) {                                                      // 68
              settings.options.submitSuccess($form, e);                                                              // 69
            }                                                                                                        // 70
          }                                                                                                          // 71
        });                                                                                                          // 72
                                                                                                                     // 73
        return this.each(function(){                                                                                 // 74
                                                                                                                     // 75
          // Get references to everything we're interested in                                                        // 76
          var $this = $(this),                                                                                       // 77
            $controlGroup = $this.parents(".control-group").first(),                                                 // 78
            $helpBlock = $controlGroup.find(".help-block").first(),                                                  // 79
            $form = $this.parents("form").first(),                                                                   // 80
            validatorNames = [];                                                                                     // 81
                                                                                                                     // 82
          // create message container if not exists                                                                  // 83
          if (!$helpBlock.length && settings.options.autoAdd && settings.options.autoAdd.helpBlocks) {               // 84
              $helpBlock = $('<div class="help-block" />');                                                          // 85
              $controlGroup.find('.controls').append($helpBlock);                                                    // 86
							createdElements.push($helpBlock[0]);                                                                          // 87
          }                                                                                                          // 88
                                                                                                                     // 89
          // =============================================================                                           // 90
          //                                     SNIFF HTML FOR VALIDATORS                                           // 91
          // =============================================================                                           // 92
                                                                                                                     // 93
          // *snort sniff snuffle*                                                                                   // 94
                                                                                                                     // 95
          if (settings.options.sniffHtml) {                                                                          // 96
            var message;                                                                                             // 97
            // ---------------------------------------------------------                                             // 98
            //                                                   PATTERN                                             // 99
            // ---------------------------------------------------------                                             // 100
            if ($this.data("validationPatternPattern")) {                                                            // 101
              $this.attr("pattern", $this.data("validationPatternPattern"));                                         // 102
            }                                                                                                        // 103
            if ($this.attr("pattern") !== undefined) {                                                               // 104
              message = "Not in the expected format<!-- data-validation-pattern-message to override -->";            // 105
              if ($this.data("validationPatternMessage")) {                                                          // 106
                message = $this.data("validationPatternMessage");                                                    // 107
              }                                                                                                      // 108
              $this.data("validationPatternMessage", message);                                                       // 109
              $this.data("validationPatternRegex", $this.attr("pattern"));                                           // 110
            }                                                                                                        // 111
            // ---------------------------------------------------------                                             // 112
            //                                                       MAX                                             // 113
            // ---------------------------------------------------------                                             // 114
            if ($this.attr("max") !== undefined || $this.attr("aria-valuemax") !== undefined) {                      // 115
              var max = ($this.attr("max") !== undefined ? $this.attr("max") : $this.attr("aria-valuemax"));         // 116
              message = "Too high: Maximum of '" + max + "'<!-- data-validation-max-message to override -->";        // 117
              if ($this.data("validationMaxMessage")) {                                                              // 118
                message = $this.data("validationMaxMessage");                                                        // 119
              }                                                                                                      // 120
              $this.data("validationMaxMessage", message);                                                           // 121
              $this.data("validationMaxMax", max);                                                                   // 122
            }                                                                                                        // 123
            // ---------------------------------------------------------                                             // 124
            //                                                       MIN                                             // 125
            // ---------------------------------------------------------                                             // 126
            if ($this.attr("min") !== undefined || $this.attr("aria-valuemin") !== undefined) {                      // 127
              var min = ($this.attr("min") !== undefined ? $this.attr("min") : $this.attr("aria-valuemin"));         // 128
              message = "Too low: Minimum of '" + min + "'<!-- data-validation-min-message to override -->";         // 129
              if ($this.data("validationMinMessage")) {                                                              // 130
                message = $this.data("validationMinMessage");                                                        // 131
              }                                                                                                      // 132
              $this.data("validationMinMessage", message);                                                           // 133
              $this.data("validationMinMin", min);                                                                   // 134
            }                                                                                                        // 135
            // ---------------------------------------------------------                                             // 136
            //                                                 MAXLENGTH                                             // 137
            // ---------------------------------------------------------                                             // 138
            if ($this.attr("maxlength") !== undefined) {                                                             // 139
              message = "Too long: Maximum of '" + $this.attr("maxlength") + "' characters<!-- data-validation-maxlength-message to override -->";
              if ($this.data("validationMaxlengthMessage")) {                                                        // 141
                message = $this.data("validationMaxlengthMessage");                                                  // 142
              }                                                                                                      // 143
              $this.data("validationMaxlengthMessage", message);                                                     // 144
              $this.data("validationMaxlengthMaxlength", $this.attr("maxlength"));                                   // 145
            }                                                                                                        // 146
            // ---------------------------------------------------------                                             // 147
            //                                                 MINLENGTH                                             // 148
            // ---------------------------------------------------------                                             // 149
            if ($this.attr("minlength") !== undefined) {                                                             // 150
              message = "Too short: Minimum of '" + $this.attr("minlength") + "' characters<!-- data-validation-minlength-message to override -->";
              if ($this.data("validationMinlengthMessage")) {                                                        // 152
                message = $this.data("validationMinlengthMessage");                                                  // 153
              }                                                                                                      // 154
              $this.data("validationMinlengthMessage", message);                                                     // 155
              $this.data("validationMinlengthMinlength", $this.attr("minlength"));                                   // 156
            }                                                                                                        // 157
            // ---------------------------------------------------------                                             // 158
            //                                                  REQUIRED                                             // 159
            // ---------------------------------------------------------                                             // 160
            if ($this.attr("required") !== undefined || $this.attr("aria-required") !== undefined) {                 // 161
              message = settings.builtInValidators.required.message;                                                 // 162
              if ($this.data("validationRequiredMessage")) {                                                         // 163
                message = $this.data("validationRequiredMessage");                                                   // 164
              }                                                                                                      // 165
              $this.data("validationRequiredMessage", message);                                                      // 166
            }                                                                                                        // 167
            // ---------------------------------------------------------                                             // 168
            //                                                    NUMBER                                             // 169
            // ---------------------------------------------------------                                             // 170
            if ($this.attr("type") !== undefined && $this.attr("type").toLowerCase() === "number") {                 // 171
              message = settings.validatorTypes.number.message; // TODO: fix this                                    // 172
              if ($this.data("validationNumberMessage")) {                                                           // 173
                message = $this.data("validationNumberMessage");                                                     // 174
              }                                                                                                      // 175
              $this.data("validationNumberMessage", message);                                                        // 176
                                                                                                                     // 177
              var step = settings.validatorTypes.number.step; // TODO: and this                                      // 178
              if ($this.data("validationNumberStep")) {                                                              // 179
                  step = $this.data("validationNumberStep");                                                         // 180
              }                                                                                                      // 181
              $this.data("validationNumberStep", step);                                                              // 182
                                                                                                                     // 183
              var decimal = settings.validatorTypes.number.decimal;                                                  // 184
              if ($this.data("validationNumberDecimal")) {                                                           // 185
                  decimal = $this.data("validationNumberDecimal");                                                   // 186
              }                                                                                                      // 187
              $this.data("validationNumberDecimal", decimal);                                                        // 188
            }                                                                                                        // 189
            // ---------------------------------------------------------                                             // 190
            //                                                     EMAIL                                             // 191
            // ---------------------------------------------------------                                             // 192
            if ($this.attr("type") !== undefined && $this.attr("type").toLowerCase() === "email") {                  // 193
              message = "Not a valid email address<!-- data-validation-email-message to override -->";               // 194
              if ($this.data("validationEmailMessage")) {                                                            // 195
                message = $this.data("validationEmailMessage");                                                      // 196
              }                                                                                                      // 197
              $this.data("validationEmailMessage", message);                                                         // 198
            }                                                                                                        // 199
            // ---------------------------------------------------------                                             // 200
            //                                                MINCHECKED                                             // 201
            // ---------------------------------------------------------                                             // 202
            if ($this.attr("minchecked") !== undefined) {                                                            // 203
              message = "Not enough options checked; Minimum of '" + $this.attr("minchecked") + "' required<!-- data-validation-minchecked-message to override -->";
              if ($this.data("validationMincheckedMessage")) {                                                       // 205
                message = $this.data("validationMincheckedMessage");                                                 // 206
              }                                                                                                      // 207
              $this.data("validationMincheckedMessage", message);                                                    // 208
              $this.data("validationMincheckedMinchecked", $this.attr("minchecked"));                                // 209
            }                                                                                                        // 210
            // ---------------------------------------------------------                                             // 211
            //                                                MAXCHECKED                                             // 212
            // ---------------------------------------------------------                                             // 213
            if ($this.attr("maxchecked") !== undefined) {                                                            // 214
              message = "Too many options checked; Maximum of '" + $this.attr("maxchecked") + "' required<!-- data-validation-maxchecked-message to override -->";
              if ($this.data("validationMaxcheckedMessage")) {                                                       // 216
                message = $this.data("validationMaxcheckedMessage");                                                 // 217
              }                                                                                                      // 218
              $this.data("validationMaxcheckedMessage", message);                                                    // 219
              $this.data("validationMaxcheckedMaxchecked", $this.attr("maxchecked"));                                // 220
            }                                                                                                        // 221
          }                                                                                                          // 222
                                                                                                                     // 223
          // =============================================================                                           // 224
          //                                       COLLECT VALIDATOR NAMES                                           // 225
          // =============================================================                                           // 226
                                                                                                                     // 227
          // Get named validators                                                                                    // 228
          if ($this.data("validation") !== undefined) {                                                              // 229
            validatorNames = $this.data("validation").split(",");                                                    // 230
          }                                                                                                          // 231
                                                                                                                     // 232
          // Get extra ones defined on the element's data attributes                                                 // 233
          $.each($this.data(), function (i, el) {                                                                    // 234
            var parts = i.replace(/([A-Z])/g, ",$1").split(",");                                                     // 235
            if (parts[0] === "validation" && parts[1]) {                                                             // 236
              validatorNames.push(parts[1]);                                                                         // 237
            }                                                                                                        // 238
          });                                                                                                        // 239
                                                                                                                     // 240
          // =============================================================                                           // 241
          //                                     NORMALISE VALIDATOR NAMES                                           // 242
          // =============================================================                                           // 243
                                                                                                                     // 244
          var validatorNamesToInspect = validatorNames;                                                              // 245
          var newValidatorNamesToInspect = [];                                                                       // 246
                                                                                                                     // 247
          var uppercaseEachValidatorName = function (i, el) {                                                        // 248
            validatorNames[i] = formatValidatorName(el);                                                             // 249
          };                                                                                                         // 250
                                                                                                                     // 251
          var inspectValidators = function(i, el) {                                                                  // 252
            if ($this.data("validation" + el + "Shortcut") !== undefined) {                                          // 253
              // Are these custom validators?                                                                        // 254
              // Pull them out!                                                                                      // 255
              $.each($this.data("validation" + el + "Shortcut").split(","), function(i2, el2) {                      // 256
                newValidatorNamesToInspect.push(el2);                                                                // 257
              });                                                                                                    // 258
            } else if (settings.builtInValidators[el.toLowerCase()]) {                                               // 259
              // Is this a recognised built-in?                                                                      // 260
              // Pull it out!                                                                                        // 261
              var validator = settings.builtInValidators[el.toLowerCase()];                                          // 262
              if (validator.type.toLowerCase() === "shortcut") {                                                     // 263
                $.each(validator.shortcut.split(","), function (i, el) {                                             // 264
                  el = formatValidatorName(el);                                                                      // 265
                  newValidatorNamesToInspect.push(el);                                                               // 266
                  validatorNames.push(el);                                                                           // 267
                });                                                                                                  // 268
              }                                                                                                      // 269
            }                                                                                                        // 270
          };                                                                                                         // 271
                                                                                                                     // 272
          do // repeatedly expand 'shortcut' validators into their real validators                                   // 273
          {                                                                                                          // 274
            // Uppercase only the first letter of each name                                                          // 275
            $.each(validatorNames, uppercaseEachValidatorName);                                                      // 276
                                                                                                                     // 277
            // Remove duplicate validator names                                                                      // 278
            validatorNames = $.unique(validatorNames);                                                               // 279
                                                                                                                     // 280
            // Pull out the new validator names from each shortcut                                                   // 281
            newValidatorNamesToInspect = [];                                                                         // 282
            $.each(validatorNamesToInspect, inspectValidators);                                                      // 283
                                                                                                                     // 284
            validatorNamesToInspect = newValidatorNamesToInspect;                                                    // 285
                                                                                                                     // 286
          } while (validatorNamesToInspect.length > 0);                                                              // 287
                                                                                                                     // 288
          // =============================================================                                           // 289
          //                                       SET UP VALIDATOR ARRAYS                                           // 290
          // =============================================================                                           // 291
                                                                                                                     // 292
          var validators = {};                                                                                       // 293
                                                                                                                     // 294
          $.each(validatorNames, function (i, el) {                                                                  // 295
            // Set up the 'override' message                                                                         // 296
            var message = $this.data("validation" + el + "Message");                                                 // 297
            var hasOverrideMessage = !!message;                                                                      // 298
            var foundValidator = false;                                                                              // 299
            if (!message) {                                                                                          // 300
              message = "'" + el + "' validation failed <!-- Add attribute 'data-validation-" + el.toLowerCase() + "-message' to input to change this message -->";
            }                                                                                                        // 302
                                                                                                                     // 303
            $.each(                                                                                                  // 304
              settings.validatorTypes,                                                                               // 305
              function (validatorType, validatorTemplate) {                                                          // 306
                if (validators[validatorType] === undefined) {                                                       // 307
                  validators[validatorType] = [];                                                                    // 308
                }                                                                                                    // 309
                if (!foundValidator && $this.data("validation" + el + formatValidatorName(validatorTemplate.name)) !== undefined) {
                  var initted = validatorTemplate.init($this, el);                                                   // 311
                  if (hasOverrideMessage) {                                                                          // 312
                    initted.message = message;                                                                       // 313
                  }                                                                                                  // 314
                                                                                                                     // 315
                  validators[validatorType].push(                                                                    // 316
                    $.extend(                                                                                        // 317
                      true,                                                                                          // 318
                      {                                                                                              // 319
                        name: formatValidatorName(validatorTemplate.name),                                           // 320
                        message: message                                                                             // 321
                      },                                                                                             // 322
                      initted                                                                                        // 323
                    )                                                                                                // 324
                  );                                                                                                 // 325
                  foundValidator = true;                                                                             // 326
                }                                                                                                    // 327
              }                                                                                                      // 328
            );                                                                                                       // 329
                                                                                                                     // 330
            if (!foundValidator && settings.builtInValidators[el.toLowerCase()]) {                                   // 331
                                                                                                                     // 332
              var validator = $.extend(true, {}, settings.builtInValidators[el.toLowerCase()]);                      // 333
              if (hasOverrideMessage) {                                                                              // 334
                validator.message = message;                                                                         // 335
              }                                                                                                      // 336
              var validatorType = validator.type.toLowerCase();                                                      // 337
                                                                                                                     // 338
              if (validatorType === "shortcut") {                                                                    // 339
                foundValidator = true;                                                                               // 340
              } else {                                                                                               // 341
                $.each(                                                                                              // 342
                  settings.validatorTypes,                                                                           // 343
                  function (validatorTemplateType, validatorTemplate) {                                              // 344
                    if (validators[validatorTemplateType] === undefined) {                                           // 345
                      validators[validatorTemplateType] = [];                                                        // 346
                    }                                                                                                // 347
                    if (!foundValidator && validatorType === validatorTemplateType.toLowerCase()) {                  // 348
                      $this.data(                                                                                    // 349
                        "validation" + el + formatValidatorName(validatorTemplate.name),                             // 350
                        validator[validatorTemplate.name.toLowerCase()]                                              // 351
                      );                                                                                             // 352
                      validators[validatorType].push(                                                                // 353
                        $.extend(                                                                                    // 354
                          validator,                                                                                 // 355
                          validatorTemplate.init($this, el)                                                          // 356
                        )                                                                                            // 357
                      );                                                                                             // 358
                      foundValidator = true;                                                                         // 359
                    }                                                                                                // 360
                  }                                                                                                  // 361
                );                                                                                                   // 362
              }                                                                                                      // 363
            }                                                                                                        // 364
                                                                                                                     // 365
            if (! foundValidator) {                                                                                  // 366
              $.error("Cannot find validation info for '" + el + "'");                                               // 367
            }                                                                                                        // 368
          });                                                                                                        // 369
                                                                                                                     // 370
          // =============================================================                                           // 371
          //                                         STORE FALLBACK VALUES                                           // 372
          // =============================================================                                           // 373
                                                                                                                     // 374
          $helpBlock.data(                                                                                           // 375
            "original-contents",                                                                                     // 376
            (                                                                                                        // 377
              $helpBlock.data("original-contents") ?                                                                 // 378
                $helpBlock.data("original-contents") :                                                               // 379
                $helpBlock.html()                                                                                    // 380
            )                                                                                                        // 381
          );                                                                                                         // 382
                                                                                                                     // 383
          $helpBlock.data(                                                                                           // 384
            "original-role",                                                                                         // 385
            (                                                                                                        // 386
              $helpBlock.data("original-role") ?                                                                     // 387
                $helpBlock.data("original-role") :                                                                   // 388
                $helpBlock.attr("role")                                                                              // 389
            )                                                                                                        // 390
          );                                                                                                         // 391
                                                                                                                     // 392
          $controlGroup.data(                                                                                        // 393
            "original-classes",                                                                                      // 394
            (                                                                                                        // 395
              $controlGroup.data("original-clases") ?                                                                // 396
                $controlGroup.data("original-classes") :                                                             // 397
                $controlGroup.attr("class")                                                                          // 398
            )                                                                                                        // 399
          );                                                                                                         // 400
                                                                                                                     // 401
          $this.data(                                                                                                // 402
            "original-aria-invalid",                                                                                 // 403
            (                                                                                                        // 404
              $this.data("original-aria-invalid") ?                                                                  // 405
                $this.data("original-aria-invalid") :                                                                // 406
                $this.attr("aria-invalid")                                                                           // 407
            )                                                                                                        // 408
          );                                                                                                         // 409
                                                                                                                     // 410
          // =============================================================                                           // 411
          //                                                    VALIDATION                                           // 412
          // =============================================================                                           // 413
                                                                                                                     // 414
          $this.bind(                                                                                                // 415
            "validation.validation",                                                                                 // 416
            function (event, params) {                                                                               // 417
                                                                                                                     // 418
              var value = getValue($this);                                                                           // 419
                                                                                                                     // 420
              // Get a list of the errors to apply                                                                   // 421
              var errorsFound = [];                                                                                  // 422
                                                                                                                     // 423
              $.each(validators, function (validatorType, validatorTypeArray) {                                      // 424
                if (                                                                                                 // 425
                    value || // has a truthy value                                                                   // 426
                    value.length || // not an empty string                                                           // 427
                    ( // am including empty values                                                                   // 428
                      (                                                                                              // 429
                        params &&                                                                                    // 430
                        params.includeEmpty                                                                          // 431
                      ) ||                                                                                           // 432
                      !!settings.validatorTypes[validatorType].includeEmpty                                          // 433
                    ) ||                                                                                             // 434
                    ( // validator is blocking submit                                                                // 435
                      !!settings.validatorTypes[validatorType].blockSubmit &&                                        // 436
                      params &&                                                                                      // 437
                      !!params.submitting                                                                            // 438
                    )                                                                                                // 439
                  )                                                                                                  // 440
                {                                                                                                    // 441
                  $.each(                                                                                            // 442
                    validatorTypeArray,                                                                              // 443
                    function (i, validator) {                                                                        // 444
                      if (settings.validatorTypes[validatorType].validate($this, value, validator)) {                // 445
                        errorsFound.push(validator.message);                                                         // 446
                      }                                                                                              // 447
                    }                                                                                                // 448
                  );                                                                                                 // 449
                }                                                                                                    // 450
              });                                                                                                    // 451
                                                                                                                     // 452
              return errorsFound;                                                                                    // 453
            }                                                                                                        // 454
          );                                                                                                         // 455
                                                                                                                     // 456
          $this.bind(                                                                                                // 457
            "getValidators.validation",                                                                              // 458
            function () {                                                                                            // 459
              return validators;                                                                                     // 460
            }                                                                                                        // 461
          );                                                                                                         // 462
                                                                                                                     // 463
          // =============================================================                                           // 464
          //                                             WATCH FOR CHANGES                                           // 465
          // =============================================================                                           // 466
          $this.bind(                                                                                                // 467
            "submit.validation",                                                                                     // 468
            function () {                                                                                            // 469
              return $this.triggerHandler("change.validation", {submitting: true});                                  // 470
            }                                                                                                        // 471
          );                                                                                                         // 472
          $this.bind(                                                                                                // 473
            (                                                                                                        // 474
                settings.options.bindEvents.length > 0 ?                                                             // 475
                settings.options.bindEvents :                                                                        // 476
                [                                                                                                    // 477
                    "keyup",                                                                                         // 478
                    "focus",                                                                                         // 479
                    "blur",                                                                                          // 480
                    "click",                                                                                         // 481
                    "keydown",                                                                                       // 482
                    "keypress",                                                                                      // 483
                    "change"                                                                                         // 484
                ]                                                                                                    // 485
            ).concat(["revalidate"]).join(".validation ") + ".validation",                                           // 486
            function (e, params) {                                                                                   // 487
                                                                                                                     // 488
              var value = getValue($this);                                                                           // 489
                                                                                                                     // 490
              var errorsFound = [];                                                                                  // 491
                                                                                                                     // 492
              if (params && !!params.submitting) {                                                                   // 493
                $controlGroup.data("jqbvIsSubmitting", true);                                                        // 494
              } else if (e.type !== "revalidate") {                                                                  // 495
                $controlGroup.data("jqbvIsSubmitting", false);                                                       // 496
              }                                                                                                      // 497
                                                                                                                     // 498
              var formIsSubmitting = !!$controlGroup.data("jqbvIsSubmitting");                                       // 499
                                                                                                                     // 500
              $controlGroup.find("input,textarea,select").each(function (i, el) {                                    // 501
                var oldCount = errorsFound.length;                                                                   // 502
                $.each($(el).triggerHandler("validation.validation", params), function (j, message) {                // 503
                  errorsFound.push(message);                                                                         // 504
                });                                                                                                  // 505
                if (errorsFound.length > oldCount) {                                                                 // 506
                  $(el).attr("aria-invalid", "true");                                                                // 507
                } else {                                                                                             // 508
                  var original = $this.data("original-aria-invalid");                                                // 509
                  $(el).attr("aria-invalid", (original !== undefined ? original : false));                           // 510
                }                                                                                                    // 511
              });                                                                                                    // 512
                                                                                                                     // 513
              $form.find("input,select,textarea").not($this).not("[name=\"" + $this.attr("name") + "\"]").trigger("validationLostFocus.validation");
                                                                                                                     // 515
              errorsFound = $.unique(errorsFound.sort());                                                            // 516
                                                                                                                     // 517
              // Were there any errors?                                                                              // 518
              if (errorsFound.length) {                                                                              // 519
                // Better flag it up as a warning.                                                                   // 520
                $controlGroup.removeClass("success error warning").addClass(formIsSubmitting ? "error" : "warning"); // 521
                                                                                                                     // 522
                // How many errors did we find?                                                                      // 523
                if (settings.options.semanticallyStrict && errorsFound.length === 1) {                               // 524
                  // Only one? Being strict? Just output it.                                                         // 525
                  $helpBlock.html(errorsFound[0] +                                                                   // 526
                    ( settings.options.prependExistingHelpBlock ? $helpBlock.data("original-contents") : "" ));      // 527
                } else {                                                                                             // 528
                  // Multiple? Being sloppy? Glue them together into an UL.                                          // 529
                  $helpBlock.html("<ul role=\"alert\"><li>" + errorsFound.join("</li><li>") + "</li></ul>" +         // 530
                    ( settings.options.prependExistingHelpBlock ? $helpBlock.data("original-contents") : "" ));      // 531
                }                                                                                                    // 532
              } else {                                                                                               // 533
                $controlGroup.removeClass("warning error success");                                                  // 534
                if (value.length > 0) {                                                                              // 535
                  $controlGroup.addClass("success");                                                                 // 536
                }                                                                                                    // 537
                $helpBlock.html($helpBlock.data("original-contents"));                                               // 538
              }                                                                                                      // 539
                                                                                                                     // 540
              if (e.type === "blur") {                                                                               // 541
                $controlGroup.removeClass("success");                                                                // 542
              }                                                                                                      // 543
            }                                                                                                        // 544
          );                                                                                                         // 545
          $this.bind("validationLostFocus.validation", function () {                                                 // 546
            $controlGroup.removeClass("success");                                                                    // 547
          });                                                                                                        // 548
        });                                                                                                          // 549
      },                                                                                                             // 550
      destroy : function( ) {                                                                                        // 551
                                                                                                                     // 552
        return this.each(                                                                                            // 553
          function() {                                                                                               // 554
                                                                                                                     // 555
            var                                                                                                      // 556
              $this = $(this),                                                                                       // 557
              $controlGroup = $this.parents(".control-group").first(),                                               // 558
              $helpBlock = $controlGroup.find(".help-block").first();                                                // 559
                                                                                                                     // 560
            // remove our events                                                                                     // 561
            $this.unbind('.validation'); // events are namespaced.                                                   // 562
            // reset help text                                                                                       // 563
            $helpBlock.html($helpBlock.data("original-contents"));                                                   // 564
            // reset classes                                                                                         // 565
            $controlGroup.attr("class", $controlGroup.data("original-classes"));                                     // 566
            // reset aria                                                                                            // 567
            $this.attr("aria-invalid", $this.data("original-aria-invalid"));                                         // 568
            // reset role                                                                                            // 569
            $helpBlock.attr("role", $this.data("original-role"));                                                    // 570
						// remove all elements we created                                                                              // 571
						if (createdElements.indexOf($helpBlock[0]) > -1) {                                                             // 572
							$helpBlock.remove();                                                                                          // 573
						}                                                                                                              // 574
                                                                                                                     // 575
          }                                                                                                          // 576
        );                                                                                                           // 577
                                                                                                                     // 578
      },                                                                                                             // 579
      collectErrors : function(includeEmpty) {                                                                       // 580
                                                                                                                     // 581
        var errorMessages = {};                                                                                      // 582
        this.each(function (i, el) {                                                                                 // 583
          var $el = $(el);                                                                                           // 584
          var name = $el.attr("name");                                                                               // 585
          var errors = $el.triggerHandler("validation.validation", {includeEmpty: true});                            // 586
          errorMessages[name] = $.extend(true, errors, errorMessages[name]);                                         // 587
        });                                                                                                          // 588
                                                                                                                     // 589
        $.each(errorMessages, function (i, el) {                                                                     // 590
          if (el.length === 0) {                                                                                     // 591
            delete errorMessages[i];                                                                                 // 592
          }                                                                                                          // 593
        });                                                                                                          // 594
                                                                                                                     // 595
        return errorMessages;                                                                                        // 596
                                                                                                                     // 597
      },                                                                                                             // 598
      hasErrors: function() {                                                                                        // 599
                                                                                                                     // 600
        var errorMessages = [];                                                                                      // 601
                                                                                                                     // 602
        this.each(function (i, el) {                                                                                 // 603
          errorMessages = errorMessages.concat(                                                                      // 604
            $(el).triggerHandler("getValidators.validation") ? $(el).triggerHandler("validation.validation", {submitting: true}) : []
          );                                                                                                         // 606
        });                                                                                                          // 607
                                                                                                                     // 608
        return (errorMessages.length > 0);                                                                           // 609
      },                                                                                                             // 610
      override : function (newDefaults) {                                                                            // 611
        defaults = $.extend(true, defaults, newDefaults);                                                            // 612
      }                                                                                                              // 613
    },                                                                                                               // 614
		validatorTypes: {                                                                                                  // 615
      callback: {                                                                                                    // 616
                name: "callback",                                                                                    // 617
                init: function($this, name) {                                                                        // 618
                    var result = {                                                                                   // 619
                        validatorName: name,                                                                         // 620
                        callback: $this.data("validation" + name + "Callback"),                                      // 621
                        lastValue: $this.val(),                                                                      // 622
                        lastValid: true,                                                                             // 623
                        lastFinished: true                                                                           // 624
                    };                                                                                               // 625
                                                                                                                     // 626
                    var message = "Not valid";                                                                       // 627
                    if ($this.data("validation" + name + "Message")) {                                               // 628
                        message = $this.data("validation" + name + "Message");                                       // 629
                    }                                                                                                // 630
                    result.message = message;                                                                        // 631
                                                                                                                     // 632
                    return result;                                                                                   // 633
                },                                                                                                   // 634
                validate: function($this, value, validator) {                                                        // 635
                    if (validator.lastValue === value && validator.lastFinished) {                                   // 636
                        return !validator.lastValid;                                                                 // 637
                    }                                                                                                // 638
                                                                                                                     // 639
                    if (validator.lastFinished === true)                                                             // 640
                    {                                                                                                // 641
                        validator.lastValue = value;                                                                 // 642
                        validator.lastValid = true;                                                                  // 643
                        validator.lastFinished = false;                                                              // 644
                                                                                                                     // 645
                        var rrjqbvValidator = validator;                                                             // 646
                        var rrjqbvThis = $this;                                                                      // 647
                        executeFunctionByName(                                                                       // 648
                            validator.callback,                                                                      // 649
                            window,                                                                                  // 650
                            $this,                                                                                   // 651
                            value,                                                                                   // 652
                            function(data) {                                                                         // 653
                                if (rrjqbvValidator.lastValue === data.value) {                                      // 654
                                    rrjqbvValidator.lastValid = data.valid;                                          // 655
                                    if (data.message) {                                                              // 656
                                        rrjqbvValidator.message = data.message;                                      // 657
                                    }                                                                                // 658
                                    rrjqbvValidator.lastFinished = true;                                             // 659
                                    rrjqbvThis.data(                                                                 // 660
                                        "validation" + rrjqbvValidator.validatorName + "Message",                    // 661
                                        rrjqbvValidator.message                                                      // 662
                                    );                                                                               // 663
                                                                                                                     // 664
                                    // Timeout is set to avoid problems with the events being considered 'already fired'
                                    setTimeout(function() {                                                          // 666
                                        if (!$this.is(":focus") && $this.parents("form").first().data("jqbvIsSubmitting")) {
                                            rrjqbvThis.trigger("blur.validation");                                   // 668
                                        } else {                                                                     // 669
                                            rrjqbvThis.trigger("revalidate.validation");                             // 670
                                        }                                                                            // 671
                                    }, 1); // doesn't need a long timeout, just long enough for the event bubble to burst
                                }                                                                                    // 673
                            }                                                                                        // 674
                        );                                                                                           // 675
                    }                                                                                                // 676
                                                                                                                     // 677
                    return false;                                                                                    // 678
                                                                                                                     // 679
                }                                                                                                    // 680
      },                                                                                                             // 681
      ajax: {                                                                                                        // 682
        name: "ajax",                                                                                                // 683
        init: function ($this, name) {                                                                               // 684
          return {                                                                                                   // 685
            validatorName: name,                                                                                     // 686
            url: $this.data("validation" + name + "Ajax"),                                                           // 687
            lastValue: $this.val(),                                                                                  // 688
            lastValid: true,                                                                                         // 689
            lastFinished: true                                                                                       // 690
          };                                                                                                         // 691
        },                                                                                                           // 692
        validate: function ($this, value, validator) {                                                               // 693
          if (""+validator.lastValue === ""+value && validator.lastFinished === true) {                              // 694
            return validator.lastValid === false;                                                                    // 695
          }                                                                                                          // 696
                                                                                                                     // 697
          if (validator.lastFinished === true)                                                                       // 698
          {                                                                                                          // 699
            validator.lastValue = value;                                                                             // 700
            validator.lastValid = true;                                                                              // 701
            validator.lastFinished = false;                                                                          // 702
            $.ajax({                                                                                                 // 703
              url: validator.url,                                                                                    // 704
              data: "value=" + encodeURIComponent(value) + "&field=" + $this.attr("name"),                           // 705
              dataType: "json",                                                                                      // 706
              success: function (data) {                                                                             // 707
                if (""+validator.lastValue === ""+data.value) {                                                      // 708
                  validator.lastValid = !!(data.valid);                                                              // 709
                  if (data.message) {                                                                                // 710
                    validator.message = data.message;                                                                // 711
                  }                                                                                                  // 712
                  validator.lastFinished = true;                                                                     // 713
                  $this.data("validation" + validator.validatorName + "Message", validator.message);                 // 714
                  // Timeout is set to avoid problems with the events being considered 'already fired'               // 715
                  setTimeout(function () {                                                                           // 716
                    $this.trigger("revalidate.validation");                                                          // 717
                  }, 1); // doesn't need a long timeout, just long enough for the event bubble to burst              // 718
                }                                                                                                    // 719
              },                                                                                                     // 720
              failure: function () {                                                                                 // 721
                validator.lastValid = true;                                                                          // 722
                validator.message = "ajax call failed";                                                              // 723
                validator.lastFinished = true;                                                                       // 724
                $this.data("validation" + validator.validatorName + "Message", validator.message);                   // 725
                // Timeout is set to avoid problems with the events being considered 'already fired'                 // 726
                setTimeout(function () {                                                                             // 727
                  $this.trigger("revalidate.validation");                                                            // 728
                }, 1); // doesn't need a long timeout, just long enough for the event bubble to burst                // 729
              }                                                                                                      // 730
            });                                                                                                      // 731
          }                                                                                                          // 732
                                                                                                                     // 733
          return false;                                                                                              // 734
                                                                                                                     // 735
        }                                                                                                            // 736
      },                                                                                                             // 737
			regex: {                                                                                                          // 738
				name: "regex",                                                                                                   // 739
				init: function ($this, name) {                                                                                   // 740
          var result = {};                                                                                           // 741
          var regexString = $this.data("validation" + name + "Regex");                                               // 742
          result.regex = regexFromString(regexString);                                                               // 743
          if (regexString === undefined) {                                                                           // 744
            $.error("Can't find regex for '" + name + "' validator on '" + $this.attr("name") + "'");                // 745
          }                                                                                                          // 746
                                                                                                                     // 747
          var message = "Not in the expected format";                                                                // 748
          if ($this.data("validation" + name + "Message")) {                                                         // 749
            message = $this.data("validation" + name + "Message");                                                   // 750
          }                                                                                                          // 751
                                                                                                                     // 752
          result.message = message;                                                                                  // 753
                                                                                                                     // 754
          result.originalName = name;                                                                                // 755
					return result;                                                                                                  // 756
				},                                                                                                               // 757
				validate: function ($this, value, validator) {                                                                   // 758
					return (!validator.regex.test(value) && ! validator.negative) ||                                                // 759
						(validator.regex.test(value) && validator.negative);                                                           // 760
				}                                                                                                                // 761
			},                                                                                                                // 762
			email: {                                                                                                          // 763
				name: "email",                                                                                                   // 764
				init: function ($this, name) {                                                                                   // 765
          var result = {};                                                                                           // 766
          result.regex = regexFromString("[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}");                        // 767
                                                                                                                     // 768
          var message = "Not a valid email address";                                                                 // 769
          if ($this.data("validation" + name + "Message")) {                                                         // 770
            message = $this.data("validation" + name + "Message");                                                   // 771
          }                                                                                                          // 772
                                                                                                                     // 773
          result.message = message;                                                                                  // 774
                                                                                                                     // 775
          result.originalName = name;                                                                                // 776
					return result;                                                                                                  // 777
				},                                                                                                               // 778
				validate: function ($this, value, validator) {                                                                   // 779
					return (!validator.regex.test(value) && ! validator.negative) ||                                                // 780
						(validator.regex.test(value) && validator.negative);                                                           // 781
				}                                                                                                                // 782
			},                                                                                                                // 783
			required: {                                                                                                       // 784
				name: "required",                                                                                                // 785
				init: function ($this, name) {                                                                                   // 786
          var message = "This is required";                                                                          // 787
          if ($this.data("validation" + name + "Message")) {                                                         // 788
            message = $this.data("validation" + name + "Message");                                                   // 789
          }                                                                                                          // 790
                                                                                                                     // 791
					return {message: message};                                                                                      // 792
				},                                                                                                               // 793
				validate: function ($this, value, validator) {                                                                   // 794
					return !!(value.length === 0  && ! validator.negative) ||                                                       // 795
						!!(value.length > 0 && validator.negative);                                                                    // 796
				},                                                                                                               // 797
        blockSubmit: true                                                                                            // 798
			},                                                                                                                // 799
			match: {                                                                                                          // 800
				name: "match",                                                                                                   // 801
				init: function ($this, name) {                                                                                   // 802
          var elementName = $this.data("validation" + name + "Match");                                               // 803
          var $form = $this.parents("form").first();                                                                 // 804
					var $element = $form.find("[name=\"" + elementName + "\"]").first();                                            // 805
					$element.bind("validation.validation", function () {                                                            // 806
						$this.trigger("revalidate.validation", {submitting: true});                                                    // 807
					});                                                                                                             // 808
          var result = {};                                                                                           // 809
          result.element = $element;                                                                                 // 810
                                                                                                                     // 811
          if ($element.length === 0) {                                                                               // 812
            $.error("Can't find field '" + elementName + "' to match '" + $this.attr("name") + "' against in '" + name + "' validator");
          }                                                                                                          // 814
                                                                                                                     // 815
          var message = "Must match";                                                                                // 816
          var $label = null;                                                                                         // 817
          if (($label = $form.find("label[for=\"" + elementName + "\"]")).length) {                                  // 818
            message += " '" + $label.text() + "'";                                                                   // 819
          } else if (($label = $element.parents(".control-group").first().find("label")).length) {                   // 820
            message += " '" + $label.first().text() + "'";                                                           // 821
          }                                                                                                          // 822
                                                                                                                     // 823
          if ($this.data("validation" + name + "Message")) {                                                         // 824
            message = $this.data("validation" + name + "Message");                                                   // 825
          }                                                                                                          // 826
                                                                                                                     // 827
          result.message = message;                                                                                  // 828
                                                                                                                     // 829
					return result;                                                                                                  // 830
				},                                                                                                               // 831
				validate: function ($this, value, validator) {                                                                   // 832
					return (value !== validator.element.val() && ! validator.negative) ||                                           // 833
						(value === validator.element.val() && validator.negative);                                                     // 834
				},                                                                                                               // 835
        blockSubmit: true,                                                                                           // 836
        includeEmpty: true                                                                                           // 837
			},                                                                                                                // 838
			max: {                                                                                                            // 839
				name: "max",                                                                                                     // 840
				init: function ($this, name) {                                                                                   // 841
          var result = {};                                                                                           // 842
                                                                                                                     // 843
          result.max = $this.data("validation" + name + "Max");                                                      // 844
                                                                                                                     // 845
          result.message = "Too high: Maximum of '" + result.max + "'";                                              // 846
          if ($this.data("validation" + name + "Message")) {                                                         // 847
            result.message = $this.data("validation" + name + "Message");                                            // 848
          }                                                                                                          // 849
                                                                                                                     // 850
					return result;                                                                                                  // 851
				},                                                                                                               // 852
				validate: function ($this, value, validator) {                                                                   // 853
					return (parseFloat(value, 10) > parseFloat(validator.max, 10) && ! validator.negative) ||                       // 854
						(parseFloat(value, 10) <= parseFloat(validator.max, 10) && validator.negative);                                // 855
				}                                                                                                                // 856
			},                                                                                                                // 857
			min: {                                                                                                            // 858
				name: "min",                                                                                                     // 859
				init: function ($this, name) {                                                                                   // 860
					var result = {};                                                                                                // 861
                                                                                                                     // 862
          result.min = $this.data("validation" + name + "Min");                                                      // 863
                                                                                                                     // 864
          result.message = "Too low: Minimum of '" + result.min + "'";                                               // 865
          if ($this.data("validation" + name + "Message")) {                                                         // 866
            result.message = $this.data("validation" + name + "Message");                                            // 867
          }                                                                                                          // 868
                                                                                                                     // 869
					return result;                                                                                                  // 870
				},                                                                                                               // 871
				validate: function ($this, value, validator) {                                                                   // 872
					return (parseFloat(value) < parseFloat(validator.min) && ! validator.negative) ||                               // 873
						(parseFloat(value) >= parseFloat(validator.min) && validator.negative);                                        // 874
				}                                                                                                                // 875
			},                                                                                                                // 876
			maxlength: {                                                                                                      // 877
				name: "maxlength",                                                                                               // 878
				init: function ($this, name) {                                                                                   // 879
          var result = {};                                                                                           // 880
                                                                                                                     // 881
          result.maxlength = $this.data("validation" + name + "Maxlength");                                          // 882
                                                                                                                     // 883
          result.message = "Too long: Maximum of '" + result.maxlength + "' characters";                             // 884
          if ($this.data("validation" + name + "Message")) {                                                         // 885
            result.message = $this.data("validation" + name + "Message");                                            // 886
          }                                                                                                          // 887
                                                                                                                     // 888
					return result;                                                                                                  // 889
				},                                                                                                               // 890
				validate: function ($this, value, validator) {                                                                   // 891
					return ((value.length > validator.maxlength) && ! validator.negative) ||                                        // 892
						((value.length <= validator.maxlength) && validator.negative);                                                 // 893
				}                                                                                                                // 894
			},                                                                                                                // 895
			minlength: {                                                                                                      // 896
				name: "minlength",                                                                                               // 897
				init: function ($this, name) {                                                                                   // 898
					var result = {};                                                                                                // 899
                                                                                                                     // 900
          result.minlength = $this.data("validation" + name + "Minlength");                                          // 901
                                                                                                                     // 902
          result.message = "Too short: Minimum of '" + result.minlength + "' characters";                            // 903
          if ($this.data("validation" + name + "Message")) {                                                         // 904
            result.message = $this.data("validation" + name + "Message");                                            // 905
          }                                                                                                          // 906
                                                                                                                     // 907
					return result;                                                                                                  // 908
				},                                                                                                               // 909
				validate: function ($this, value, validator) {                                                                   // 910
					return ((value.length < validator.minlength) && ! validator.negative) ||                                        // 911
						((value.length >= validator.minlength) && validator.negative);                                                 // 912
				}                                                                                                                // 913
			},                                                                                                                // 914
			maxchecked: {                                                                                                     // 915
				name: "maxchecked",                                                                                              // 916
				init: function ($this, name) {                                                                                   // 917
          var result = {};                                                                                           // 918
                                                                                                                     // 919
					var elements = $this.parents("form").first().find("[name=\"" + $this.attr("name") + "\"]");                     // 920
					elements.bind("change.validation click.validation", function () {                                               // 921
						$this.trigger("revalidate.validation", {includeEmpty: true});                                                  // 922
					});                                                                                                             // 923
                                                                                                                     // 924
          result.elements = elements;                                                                                // 925
          result.maxchecked = $this.data("validation" + name + "Maxchecked");                                        // 926
                                                                                                                     // 927
          var message = "Too many: Max '" + result.maxchecked + "' checked";                                         // 928
          if ($this.data("validation" + name + "Message")) {                                                         // 929
            message = $this.data("validation" + name + "Message");                                                   // 930
          }                                                                                                          // 931
          result.message = message;                                                                                  // 932
                                                                                                                     // 933
					return result;                                                                                                  // 934
				},                                                                                                               // 935
				validate: function ($this, value, validator) {                                                                   // 936
					return (validator.elements.filter(":checked").length > validator.maxchecked && ! validator.negative) ||         // 937
						(validator.elements.filter(":checked").length <= validator.maxchecked && validator.negative);                  // 938
				},                                                                                                               // 939
        blockSubmit: true                                                                                            // 940
			},                                                                                                                // 941
			minchecked: {                                                                                                     // 942
				name: "minchecked",                                                                                              // 943
				init: function ($this, name) {                                                                                   // 944
          var result = {};                                                                                           // 945
                                                                                                                     // 946
					var elements = $this.parents("form").first().find("[name=\"" + $this.attr("name") + "\"]");                     // 947
					elements.bind("change.validation click.validation", function () {                                               // 948
						$this.trigger("revalidate.validation", {includeEmpty: true});                                                  // 949
					});                                                                                                             // 950
                                                                                                                     // 951
          result.elements = elements;                                                                                // 952
          result.minchecked = $this.data("validation" + name + "Minchecked");                                        // 953
                                                                                                                     // 954
          var message = "Too few: Min '" + result.minchecked + "' checked";                                          // 955
          if ($this.data("validation" + name + "Message")) {                                                         // 956
            message = $this.data("validation" + name + "Message");                                                   // 957
          }                                                                                                          // 958
          result.message = message;                                                                                  // 959
                                                                                                                     // 960
					return result;                                                                                                  // 961
				},                                                                                                               // 962
				validate: function ($this, value, validator) {                                                                   // 963
					return (validator.elements.filter(":checked").length < validator.minchecked && ! validator.negative) ||         // 964
						(validator.elements.filter(":checked").length >= validator.minchecked && validator.negative);                  // 965
				},                                                                                                               // 966
        blockSubmit: true,                                                                                           // 967
        includeEmpty: true                                                                                           // 968
			},                                                                                                                // 969
      number: {                                                                                                      // 970
        name: "number",                                                                                              // 971
        init: function ($this, name) {                                                                               // 972
          var result = {};                                                                                           // 973
          result.step = 1;                                                                                           // 974
          if ($this.attr("step")) {                                                                                  // 975
            result.step = $this.attr("step");                                                                        // 976
          }                                                                                                          // 977
          if ($this.data("validation" + name + "Step")) {                                                            // 978
            result.step = $this.data("validation" + name + "Step");                                                  // 979
          }                                                                                                          // 980
                                                                                                                     // 981
          result.decimal = ".";                                                                                      // 982
          if ($this.data("validation" + name + "Decimal")) {                                                         // 983
            result.decimal = $this.data("validation" + name + "Decimal");                                            // 984
          }                                                                                                          // 985
                                                                                                                     // 986
          result.thousands = "";                                                                                     // 987
          if ($this.data("validation" + name + "Thousands")) {                                                       // 988
            result.thousands = $this.data("validation" + name + "Thousands");                                        // 989
          }                                                                                                          // 990
                                                                                                                     // 991
          result.regex = regexFromString("([+-]?\\d+(\\" + result.decimal + "\\d+)?)?");                             // 992
                                                                                                                     // 993
          result.message = "Must be a number";                                                                       // 994
          var dataMessage = $this.data("validation" + name + "Message");                                             // 995
          if (dataMessage) {                                                                                         // 996
            result.message = dataMessage;                                                                            // 997
          }                                                                                                          // 998
                                                                                                                     // 999
          return result;                                                                                             // 1000
        },                                                                                                           // 1001
        validate: function ($this, value, validator) {                                                               // 1002
          var globalValue = value.replace(validator.decimal, ".").replace(validator.thousands, "");                  // 1003
          var multipliedValue = parseFloat(globalValue);                                                             // 1004
          var multipliedStep = parseFloat(validator.step);                                                           // 1005
          while (multipliedStep % 1 !== 0) {                                                                         // 1006
            multipliedStep *= 10;                                                                                    // 1007
            multipliedValue *= 10;                                                                                   // 1008
          }                                                                                                          // 1009
          var regexResult = validator.regex.test(value);                                                             // 1010
          var stepResult = parseFloat(multipliedValue) % parseFloat(multipliedStep) === 0;                           // 1011
          var typeResult = !isNaN(parseFloat(globalValue)) && isFinite(globalValue);                                 // 1012
          var result = !(regexResult && stepResult && typeResult);                                                   // 1013
          return result;                                                                                             // 1014
        },                                                                                                           // 1015
        message: "Must be a number"                                                                                  // 1016
      }                                                                                                              // 1017
		},                                                                                                                 // 1018
		builtInValidators: {                                                                                               // 1019
			email: {                                                                                                          // 1020
				name: "Email",                                                                                                   // 1021
				type: "email"                                                                                                    // 1022
			},                                                                                                                // 1023
			passwordagain: {                                                                                                  // 1024
				name: "Passwordagain",                                                                                           // 1025
				type: "match",                                                                                                   // 1026
				match: "password",                                                                                               // 1027
				message: "Does not match the given password<!-- data-validator-paswordagain-message to override -->"             // 1028
			},                                                                                                                // 1029
			positive: {                                                                                                       // 1030
				name: "Positive",                                                                                                // 1031
				type: "shortcut",                                                                                                // 1032
				shortcut: "number,positivenumber"                                                                                // 1033
			},                                                                                                                // 1034
			negative: {                                                                                                       // 1035
				name: "Negative",                                                                                                // 1036
				type: "shortcut",                                                                                                // 1037
				shortcut: "number,negativenumber"                                                                                // 1038
			},                                                                                                                // 1039
			integer: {                                                                                                        // 1040
				name: "Integer",                                                                                                 // 1041
				type: "regex",                                                                                                   // 1042
				regex: "[+-]?\\d+",                                                                                              // 1043
				message: "No decimal places allowed<!-- data-validator-integer-message to override -->"                          // 1044
			},                                                                                                                // 1045
			positivenumber: {                                                                                                 // 1046
				name: "Positivenumber",                                                                                          // 1047
				type: "min",                                                                                                     // 1048
				min: 0,                                                                                                          // 1049
				message: "Must be a positive number<!-- data-validator-positivenumber-message to override -->"                   // 1050
			},                                                                                                                // 1051
			negativenumber: {                                                                                                 // 1052
				name: "Negativenumber",                                                                                          // 1053
				type: "max",                                                                                                     // 1054
				max: 0,                                                                                                          // 1055
				message: "Must be a negative number<!-- data-validator-negativenumber-message to override -->"                   // 1056
			},                                                                                                                // 1057
			required: {                                                                                                       // 1058
				name: "Required",                                                                                                // 1059
				type: "required",                                                                                                // 1060
				message: "This is required<!-- data-validator-required-message to override -->"                                  // 1061
			},                                                                                                                // 1062
			checkone: {                                                                                                       // 1063
				name: "Checkone",                                                                                                // 1064
				type: "minchecked",                                                                                              // 1065
				minchecked: 1,                                                                                                   // 1066
				message: "Check at least one option<!-- data-validation-checkone-message to override -->"                        // 1067
			},                                                                                                                // 1068
      number: {                                                                                                      // 1069
        name: "Number",                                                                                              // 1070
        type: "number",                                                                                              // 1071
        decimal: ".",                                                                                                // 1072
        step: "1"                                                                                                    // 1073
			},                                                                                                                // 1074
      pattern: {                                                                                                     // 1075
        name: "Pattern",                                                                                             // 1076
        type: "regex",                                                                                               // 1077
        message: "Not in expected format"                                                                            // 1078
      }                                                                                                              // 1079
		}                                                                                                                  // 1080
	};                                                                                                                  // 1081
                                                                                                                     // 1082
	var formatValidatorName = function (name) {                                                                         // 1083
		return name                                                                                                        // 1084
			.toLowerCase()                                                                                                    // 1085
			.replace(                                                                                                         // 1086
				/(^|\s)([a-z])/g ,                                                                                               // 1087
				function(m,p1,p2) {                                                                                              // 1088
					return p1+p2.toUpperCase();                                                                                     // 1089
				}                                                                                                                // 1090
			)                                                                                                                 // 1091
		;                                                                                                                  // 1092
	};                                                                                                                  // 1093
                                                                                                                     // 1094
	var getValue = function ($this) {                                                                                   // 1095
		// Extract the value we're talking about                                                                           // 1096
		var value = $this.val();                                                                                           // 1097
		var type = $this.attr("type");                                                                                     // 1098
    var parent = null;                                                                                               // 1099
    var hasParent = !!(parent = $this.parents("form").first()) || !!(parent = $this.parents(".control-group").first());
		if (type === "checkbox") {                                                                                         // 1101
      value = ($this.is(":checked") ? value : "");                                                                   // 1102
      if (hasParent) {                                                                                               // 1103
        value = parent.find("input[type='checkbox'][name='" + $this.attr("name") + "']:checked").map(function (i, el) { return $(el).val(); }).toArray().join(",");
      }                                                                                                              // 1105
		}                                                                                                                  // 1106
		if (type === "radio") {                                                                                            // 1107
			value = ($('input[name="' + $this.attr("name") + '"]:checked').length > 0 ? value : "");                          // 1108
      if (hasParent) {                                                                                               // 1109
        value = parent.find("input[type='radio'][name='" + $this.attr("name") + "']:checked").map(function (i, el) { return $(el).val(); }).toArray().join(",");
      }                                                                                                              // 1111
		}                                                                                                                  // 1112
		return value;                                                                                                      // 1113
	};                                                                                                                  // 1114
                                                                                                                     // 1115
  function regexFromString(inputstring) {                                                                            // 1116
		return new RegExp("^" + inputstring + "$");                                                                        // 1117
	}                                                                                                                   // 1118
                                                                                                                     // 1119
  /**                                                                                                                // 1120
   * Thanks to Jason Bunting via StackOverflow.com                                                                   // 1121
   *                                                                                                                 // 1122
   * http://stackoverflow.com/questions/359788/how-to-execute-a-javascript-function-when-i-have-its-name-as-a-string#answer-359910
   * Short link: http://tinyurl.com/executeFunctionByName                                                            // 1124
  **/                                                                                                                // 1125
  function executeFunctionByName(functionName, context /*, args*/) {                                                 // 1126
    var args = Array.prototype.slice.call(arguments).splice(2);                                                      // 1127
    var namespaces = functionName.split(".");                                                                        // 1128
    var func = namespaces.pop();                                                                                     // 1129
    for(var i = 0; i < namespaces.length; i++) {                                                                     // 1130
      context = context[namespaces[i]];                                                                              // 1131
    }                                                                                                                // 1132
    return context[func].apply(this, args);                                                                          // 1133
  }                                                                                                                  // 1134
                                                                                                                     // 1135
	$.fn.jqBootstrapValidation = function( method ) {                                                                   // 1136
                                                                                                                     // 1137
		if ( defaults.methods[method] ) {                                                                                  // 1138
			return defaults.methods[method].apply( this, Array.prototype.slice.call( arguments, 1 ));                         // 1139
		} else if ( typeof method === 'object' || ! method ) {                                                             // 1140
			return defaults.methods.init.apply( this, arguments );                                                            // 1141
		} else {                                                                                                           // 1142
		$.error( 'Method ' +  method + ' does not exist on jQuery.jqBootstrapValidation' );                                // 1143
			return null;                                                                                                      // 1144
		}                                                                                                                  // 1145
                                                                                                                     // 1146
	};                                                                                                                  // 1147
                                                                                                                     // 1148
  $.jqBootstrapValidation = function (options) {                                                                     // 1149
    $(":input").not("[type=image],[type=submit]").jqBootstrapValidation.apply(this,arguments);                       // 1150
  };                                                                                                                 // 1151
                                                                                                                     // 1152
})( jQuery );                                                                                                        // 1153
                                                                                                                     // 1154
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package.jqbootstrapvalidation = {};

})();

//# sourceMappingURL=1b58b05e36f56c1cbe174c399c2026b5f443a2be.map
