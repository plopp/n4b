(function(){Scenarios = new Meteor.Collection('scenarios');

})();
