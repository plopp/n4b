(function(){Pvdata = new Meteor.Collection('pvdata');

})();
