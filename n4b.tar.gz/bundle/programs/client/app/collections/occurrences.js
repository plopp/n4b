(function(){Occurrences = new Meteor.Collection('occurrences');

})();
