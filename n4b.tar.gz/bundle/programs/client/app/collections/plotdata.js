(function(){Plotdata = new Meteor.Collection('plotdata');

})();
