(function(){Resources = new Meteor.Collection('resources');

})();
