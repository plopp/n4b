(function(){Jobs = new Meteor.Collection('jobs');

})();
