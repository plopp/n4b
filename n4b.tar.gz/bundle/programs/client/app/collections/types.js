(function(){Types = new Meteor.Collection('types');

})();
