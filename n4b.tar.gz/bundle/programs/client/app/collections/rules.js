(function(){Rules = new Meteor.Collection('rules');

})();
