(function(){Meteor.startup(function(){document.body.appendChild(Spark.render(Template.__define__(null,Package.handlebars.Handlebars.json_ast_to_func(["<div class=\"container\">\n    ",[">","header"],"\n    <div id=\"main\" class=\"row-fluid\">\n      ",["{",[[0,"renderPage"]]],"\n    </div>\n  </div>"]))));});

})();
