(function(){Template.logsPage.helpers({
});

Template.logsPage.events({
});

})();
