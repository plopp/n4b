(function(){Template.__define__("dataPage",Package.handlebars.Handlebars.json_ast_to_func(["<div>\n  <div class=\"content\" style=\"display: block; horizontal-align: center\">\n    \n      <div id=\"myChart\" width=\"600\" height=\"400\"></div>\n\n\t</div>\n</div>"]));

})();
