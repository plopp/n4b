(function(){Template.__define__("resourcePage",Package.handlebars.Handlebars.json_ast_to_func(["<ul class=\"rules\">\n    ",[">","resourceList"],"\n    </ul>\n\t\n    <!--<ul class=\"rules\">\n      ",["#",[[0,"each"],[0,"rules"]],["\n        ",[">","ruleItem"],"\n      "]],"\n    </ul>-->\n\n   \n    <!--\n    ",["#",[[0,"if"],[0,"currentUser"]],["\n      ",[">","ruleSubmit"],"\n    "],["\n      <p>Please log in to create a rule.</p>\n    "]],"-->"]));

})();
