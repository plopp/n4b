(function(){Template.resourcePage.helpers({
    
});

})();
