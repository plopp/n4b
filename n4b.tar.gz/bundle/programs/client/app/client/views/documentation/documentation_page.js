(function(){Template.documentationPage.helpers({
});

Template.documentationPage.events({
});

})();
