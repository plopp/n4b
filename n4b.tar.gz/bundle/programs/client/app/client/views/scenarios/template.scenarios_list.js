(function(){Template.__define__("scenariosList",Package.handlebars.Handlebars.json_ast_to_func(["<div class=\"scenarios\">\n    ",["#",[[0,"each"],[0,"scenario"]],["\n      ",[">","scenarioItem"],"\n    "]],"\n  </div>\n\t<form>\n\t  <div class=\"control-group\">\n\t\t    <div class=\"controls\">\n\t\t        <input type=\"submit\" value=\"+ Add scenario\" class=\"btn btn-primary\"/>\n\t\t    </div>\n\t\t</div>\n\t</form>"]));

})();
